"use strict";Object.defineProperty(exports,"__esModule",{value:true});function e(e){var r=false;var t;return function(){if(r){return t}t=e();r=true;return t}}exports.doOnce=e;
