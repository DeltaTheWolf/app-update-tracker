"use strict";Object.defineProperty(exports,"__esModule",{value:true});function e(t){return function(e){return e.type==t}}exports.isAttachmentTypeFactory=e;
