"use strict";Object.defineProperty(exports,"__esModule",{value:true});exports.AttachmentType={ADDRESS:"ADDRESS",WEB_LINK:"WEB_LINK",PHONE:"PHONE",SNAPCHATTER:"SNAPCHATTER"};
